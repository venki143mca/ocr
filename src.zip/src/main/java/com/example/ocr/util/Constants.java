package com.example.ocr.util;

/**
 * Any constants.
 */
public class Constants {
    public static final int CONNECT_TIMEOUT = 10000;
    public static final int READ_TIMEOUT = 10000;
    public static final String BASE_URL="https://pdfpiw.uspto.gov/";
}
