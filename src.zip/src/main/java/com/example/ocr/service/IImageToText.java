package com.example.ocr.service;

import java.io.File;

public interface IImageToText {
    String getDataFromImage(File newFile);
}
